<?php
require_once 'vendor/autoload.php';
require_once 'lib/config_helper.php';
require_once 'lib/logger.php';

$logger = ScapeLogger::getInstance();

echo "<h1>OIDC Configuration Debug</h1>";

// Test configuration loading
echo "<h2>Configuration Test</h2>";
$config = get_app_config();

echo "<h3>Customer (B2C) Configuration:</h3>";
echo "Tenant ID: " . htmlspecialchars($config['b2c']['tenant_id'] ?? 'NOT SET') . "<br>";
echo "Client ID: " . htmlspecialchars($config['b2c']['client_id'] ?? 'NOT SET') . "<br>";
echo "Domain: " . htmlspecialchars($config['b2c']['domain'] ?? 'NOT SET') . "<br>";

echo "<h3>Agent (B2B) Configuration:</h3>";
echo "Tenant ID: " . htmlspecialchars($config['b2b']['tenant_id'] ?? 'NOT SET') . "<br>";
echo "Client ID: " . htmlspecialchars($config['b2b']['client_id'] ?? 'NOT SET') . "<br>";
echo "Authority: " . htmlspecialchars($config['b2b']['authority'] ?? 'NOT SET') . "<br>";

// Test OIDC client creation
echo "<h2>OIDC Client Test</h2>";

try {
    require_once 'lib/oidc.php';
    
    echo "<h3>Testing Customer Client Creation:</h3>";
    try {
        $customerClient = get_oidc_client('customer');
        echo "✅ Customer OIDC client created successfully<br>";
    } catch (Exception $e) {
        echo "❌ Customer OIDC client failed: " . htmlspecialchars($e->getMessage()) . "<br>";
    }
    
    echo "<h3>Testing Agent Client Creation:</h3>";
    try {
        $agentClient = get_oidc_client('agent');
        echo "✅ Agent OIDC client created successfully<br>";
    } catch (Exception $e) {
        echo "❌ Agent OIDC client failed: " . htmlspecialchars($e->getMessage()) . "<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Failed to load OIDC library: " . htmlspecialchars($e->getMessage()) . "<br>";
}

echo "<h2>Environment Variables</h2>";
echo "Environment file exists: " . (file_exists('.env') ? '✅ Yes' : '❌ No') . "<br>";

if (file_exists('.env')) {
    echo "<h3>.env file contents:</h3>";
    echo "<pre>" . htmlspecialchars(file_get_contents('.env')) . "</pre>";
}

// Check what environment variables are actually set
echo "<h3>Environment Variables (from config helper):</h3>";
$envVars = ['EXTERNAL_TENANT_ID', 'EXTERNAL_CLIENT_ID', 'EXTERNAL_CLIENT_SECRET', 
           'INTERNAL_TENANT_ID', 'INTERNAL_CLIENT_ID', 'INTERNAL_CLIENT_SECRET'];

foreach ($envVars as $var) {
    $value = getenv($var);
    if ($value === false) {
        echo "$var: ❌ Not set<br>";
    } else {
        echo "$var: ✅ Set (length: " . strlen($value) . ")<br>";
    }
}
?>
